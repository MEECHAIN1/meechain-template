// This file contains the AWS EventBridge related functions

import { EventBridgeClient, PutEventsCommand } from '@aws-sdk/client-eventbridge'

/**
 * Triggers a fallback mint event in EventBridge
 * @param userAddress - The address of the user triggering the event
 * @param questId - The ID of the quest associated with the event
 * @param userId - The ID of the user triggering the event
 */
export async function triggerFallbackMint(userAddress: string, questId: string, userId: string) {
    const client = new EventBridgeClient({ region: 'ap-southeast-1' })
    const command = new PutEventsCommand({
        Entries: [
            {
                Source: 'meechain.quest',
                DetailType: 'FallbackMintRequest',
                EventBusName: 'MeeChainBus',
                Detail: JSON.stringify({ userAddress, questId, userId }),
            },
        ],
    })

    await client.send(command)
}