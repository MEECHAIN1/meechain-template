export async function transferBadgeOwnership(newOwner: string, signer: ethers.Signer) {
  const contract = getBadgeMintContract(signer)
  const tx = await contract.completeToOwnable(newOwner)
  await tx.wait()
  return tx.hash
}
