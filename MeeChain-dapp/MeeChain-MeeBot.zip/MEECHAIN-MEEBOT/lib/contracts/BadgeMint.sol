// lib/contracts/badgeMint.ts
import { ethers } from 'ethers'
import BadgeMintABI from '@/artifacts/contracts/BadgeMint.sol/BadgeMint.json'

export const badgeMintAddress = '0xYourContractAddressHere'

export function getBadgeMintContract(providerOrSigner: ethers.Signer | ethers.Provider) {
  return new ethers.Contract(badgeMintAddress, BadgeMintABI.abi, providerOrSigner)
}
