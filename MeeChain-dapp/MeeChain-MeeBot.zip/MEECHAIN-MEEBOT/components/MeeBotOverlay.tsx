import { ethers } from 'ethers'

export default function MeeBotOverlay({ reaction }: { reaction: string }) {
    const emoji = {
        celebrate: '🎉',
        fallback: '😢',
        badgeFlip: '🪙',
        bounce: '🤖',
    }[reaction] || '👋'

    return (
        <div className= "meebot-overlay" >
        <p>{ emoji } MeeBot says: { reaction === 'celebrate' ? 'สุดยอดเลย!' : 'ลองใหม่อีกครั้งนะ!' } </p>
    < /div>,
}

const provider = new ethers.JsonRpcProvider(process.env.RPC_URL_PREVIEW)
const badgeContract = new ethers.Contract(
    contractConfig.badgeNFT.address,
    contractConfig.badgeNFT.abi,
    provider
  )
