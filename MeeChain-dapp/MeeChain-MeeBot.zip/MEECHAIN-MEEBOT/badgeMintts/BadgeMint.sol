// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract BadgeMint is ERC721URIStorage, Ownable {
    uint256 public nextBadgeId = 1;

    constructor() ERC721("MeeChainBadge", "MCB") Ownable(msg.sender) {}


    function mintBadge(address recipient, string memory metadataURI) public onlyOwner {
        uint256 badgeId = nextBadgeId;
        _safeMint(recipient, badgeId);
        _setTokenURI(badgeId, metadataURI);
        nextBadgeId++;
    }

    function getLastBadgeId() public view returns (uint256) {
        return nextBadgeId - 1;
    }
}
// contracts/BadgeMint.sol
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract BadgeMint {
    address public owner;
    mapping(address => mapping(string => bool)) public minted;

    event BadgeMinted(address indexed user, string questId);

    constructor() {
        owner = msg.sender;
    }

    function mintBadge(address user, string memory questId) public {
        require(msg.sender == owner, "Only owner can mint");
        require(!minted[user][questId], "Already minted");

        minted[user][questId] = true;
        emit BadgeMinted(user, questId);
    }

    function completeToOwnable(address newOwner) public {
        require(msg.sender == owner, "Only owner can transfer");
        owner = newOwner;
    }
}
