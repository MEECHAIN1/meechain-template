import { getBadgeMintContract } from '@/lib/contracts/badgeMint'
import { ethers } from 'ethers'

export default async function handler(req, res) {
    const { userAddress, questId } = req.body

    const provider = new ethers.JsonRpcProvider(process.env.RPC_URL)
    const signer = new ethers.Wallet(process.env.PRIVATE_KEY, provider)
    const contract = getBadgeMintContract(signer)

    const tx = await contract.mintBadge(userAddress, questId)
    await tx.wait()

    res.status(200).json({ success: true, txHash: tx.hash })
}
