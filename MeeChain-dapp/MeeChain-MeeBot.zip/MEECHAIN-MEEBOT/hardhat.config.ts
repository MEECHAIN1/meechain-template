import { ethers } from 'ethers'
import BadgeMintABI from '@/artifacts/contracts/BadgeMint.sol/BadgeMint.json'

export const badgeMintAddress = 0x499bF335E8A0212138da4e9d6056710F11d58bd4

export function getBadgeMintContract(providerOrSigner: ethers.Signer | ethers.Provider) {
    return new ethers.Contract(badgeMintAddress, BadgeMintABI.abi, providerOrSigner)
}
