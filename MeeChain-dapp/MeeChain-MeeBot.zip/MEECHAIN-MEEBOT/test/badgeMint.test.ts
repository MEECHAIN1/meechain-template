import { ethers } from 'ethers'
import { getBadgeMintContract } from './contracts/badgeMint'
import fetch from 'node-fetch';

export const handler = async (event) => {
    const { userAddress, questId } = JSON.parse(event.detail)

    const provider = new ethers.JsonRpcProvider(process.env.RPC_URL)
    const signer = new ethers.Wallet(process.env.FALLBACK_MINT_PRIVATE_KEY, provider)
    const contract = getBadgeMintContract(signer)

    const tx = await contract.mintBadge(userAddress, questId)
    await tx.wait()

    console.log('Fallback mint successful:', tx.hash)
}

    const requestBody = {
        userId,
        questId,
        tokenId: tx.hash,
        mintedBy: 'fallback',
    };

    await fetch(process.env.NEON_SYNC_API, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
    });

    return { status: 'minted', txHash: tx.hash };
}