//File： fs://d4711178426e4173a968be0aec77edb1/readme.md
## HelloWorld

This program uses Solidity's 'if' and 'event' features to build a smart contract that sends the "Hello World" message to the contract deployer and sends the address and the "Hello EVM" message to everyone except the contract deployer.