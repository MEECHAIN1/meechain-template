// SPDX-License-Identifier: MIT
// OpenZeppelin Contracts (last updated v5.0.1) (utils/Context.sol)

pragma solidity ^0.8.20;
import { ethers } from 'ethers'
import { getBadgeMintContract } from './contracts/badgeMint'

export const handler = async (event) => {
  const { userAddress, questId } = JSON.parse(event.detail)

  const provider = new ethers.JsonRpcProvider(process.env.RPC_URL)
  const signer = new ethers.Wallet(process.env.FALLBACK_MINT_PRIVATE_KEY, provider)
  const contract = getBadgeMintContract(signer)

  const tx = await contract.mintBadge(userAddress, questId)
  await tx.wait()

  console.log('Fallback mint successful:', tx.hash)
}

/**
 * @dev Provides information about the current execution context, including the
 * sender of the transaction and its data. While these are generally available
 * via msg.sender and msg.data, they should not be accessed in such a direct
 * manner, since when dealing with meta-transactions the account sending and
 * paying for execution may not be the actual sender (as far as an application
 * is concerned).
 *
 * This contract is only required for intermediate, library-like contracts.
 */
abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }

    function _contextSuffixLength() internal view virtual returns (uint256) {
        return 0;
    }
}
