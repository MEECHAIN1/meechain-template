import type { HardhatUserConfig } from "hardhat/types";
import "@nomiclabs/hardhat-ethers";
import { ethers } from 'ethers'
import { getBadgeMintContract } from '@/lib/contracts/badgeMint'

export async function mintBadgeWithFallback(userAddress: string, questId: string) {
    try {
        const provider = new ethers.JsonRpcProvider(process.env.RPC_URL)
        const signer = new ethers.Wallet(process.env.PRIVATE_KEY, provider) // ผู้ใช้ mint เอง

        const contract = getBadgeMintContract(signer)
        const tx = await contract.mintBadge(userAddress, questId)
        await tx.wait()
        return { txHash: tx.hash, fallback: false }
    } catch (error) {
        console.warn('Mint failed, using fallback:', error)

        const provider = new ethers.JsonRpcProvider(process.env.RPC_URL)
        const fallbackSigner = new ethers.Wallet(process.env.FALLBACK_MINT_PRIVATE_KEY, provider)

        const contract = getBadgeMintContract(fallbackSigner)
        const tx = await contract.mintBadge(userAddress, questId)
        await tx.wait()
        return { txHash: tx.hash, fallback: true }
    }
}
const config: HardhatUserConfig = {
    solidity: "v0.8.30+commit.73712a01"
};

export default config;