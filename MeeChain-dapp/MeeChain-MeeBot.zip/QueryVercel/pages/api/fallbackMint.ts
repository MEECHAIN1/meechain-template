import { triggerFallbackMint } from '@/lib/aws/eventbridge'

<MeeBotOverlay reaction={ fallback ? 'badgeFlip' : 'celebrate' } />

export default async function handler(req, res) {
    const { userAddress, questId, userId } = req.body

    try {
        await triggerFallbackMint(userAddress, questId, userId)
        res.status(200).json({ status: 'queued' })
    } catch (error) {
        console.error('Fallback mint error:', error)
        res.status(500).json({ error: 'Failed to trigger fallback mint' })
    }
}
