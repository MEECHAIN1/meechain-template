import type { NextApiRequest, NextApiResponse } from 'next';
import { saveLog } from '@/lib/db';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    const token = req.headers.authorization?.replace('Bearer ', '');
    if (token !== process.env.MEECHAIN_READ_WRITE_TOKEN) {
        return res.status(403).json({ error: 'Unauthorized' });
    }

    const { workspace, network, url, commit, status } = req.body;
    await saveLog({ workspace, network, url, commit, status, timestamp: Date.now() });
    res.status(200).json({ ok: true });
}