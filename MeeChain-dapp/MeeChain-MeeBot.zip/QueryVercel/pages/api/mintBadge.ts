import { ethers } from 'ethers'
import BadgeMintABI from '@/artifacts/contracts/BadgeMint.sol/BadgeMint.json'
import { getBadgeMintContract } from '@/lib/contracts/badgeMint'

<MeeBotOverlay reaction={ fallback ? 'badgeFlip' : 'celebrate' } />

export const badgeMintAddress = '0xYourContractAddressHere'
    await prisma.badge.create({
      data: {
        userId,
        questId,
        tokenId: tx.hash,
        mintedAt: new Date(),
        },
    })

export function getBadgeMintContract(providerOrSigner: ethers.Signer | ethers.Provider) {
     return new ethers.Contract(badgeMintAddress, BadgeMintABI.abi, providerOrSigner)
}

export async function transferBadgeOwnership(newOwner: string, signer: ethers.Signer) {
    const contract = getBadgeMintContract(signer)
    const tx = await contract.completeToOwnable(newOwner)
    await tx.wait()
    return tx.hash
}

export default async function handler(req, res) {
    const { userAddress, questId } = req.body

    const provider = new ethers.JsonRpcProvider(process.env.RPC_URL)
    const signer = new ethers.Wallet(process.env.PRIVATE_KEY, provider)
    const contract = getBadgeMintContract(signer)

    const tx = await contract.mintBadge(userAddress, questId)
    await tx.wait()

    res.status(200).json({ success: true, txHash: tx.hash })
}